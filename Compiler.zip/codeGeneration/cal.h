//
// Created by hp on 2024/10/27.
//

#ifndef COMPILER_CAL_H
#define COMPILER_CAL_H


#include <string>

class cal {
    static void calExp(const std::string& exp);
};


#endif //COMPILER_CAL_H
