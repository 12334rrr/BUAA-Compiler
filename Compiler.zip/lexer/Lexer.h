//
// Created by hp on 2024/10/3.
//

#ifndef COMPILER_LEXER_H
#define COMPILER_LEXER_H


class Lexer {
public:
    static void lexicalAnalysis();
};


#endif //COMPILER_LEXER_H
