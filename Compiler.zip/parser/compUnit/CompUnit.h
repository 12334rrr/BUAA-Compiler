/**

 */

#ifndef COMPILER_COMPUNIT_H
#define COMPILER_COMPUNIT_H

#include <string>
#include <vector>

class CompUnit {
private:

public:
    static void compUnitParser();
};


#endif //COMPILER_COMPUNIT_H
