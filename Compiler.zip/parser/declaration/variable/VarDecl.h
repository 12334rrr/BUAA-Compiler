//
// Created by hp on 2024/10/9.
//

#ifndef COMPILER_VARDECL_H
#define COMPILER_VARDECL_H


class VarDecl {
public:
    static void varDeclParser();
};


#endif //COMPILER_VARDECL_H
