/**
 * @file LAndExp.h
 * @brief 逻辑与表达式类
 * @version 1.0
 * @date 2024-10-03
 * @Author  王春博
 */

#ifndef COMPILER_LANDEXP_H
#define COMPILER_LANDEXP_H


class LAndExp {
public:
    static void lAndExpParser();
};


#endif //COMPILER_LANDEXP_H
