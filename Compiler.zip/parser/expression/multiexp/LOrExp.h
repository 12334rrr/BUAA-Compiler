/**
 * @file LOrExp.h
 * @brief Class for logical or expression.
 * @version 1.0
 * @date 2024-10-03
 * @Author  王春博
 */

#ifndef COMPILER_LOREXP_H
#define COMPILER_LOREXP_H


class LOrExp {
public:
    static void lOrExpParser();
};


#endif //COMPILER_LOREXP_H
