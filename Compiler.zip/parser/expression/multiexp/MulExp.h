//
// Created by hp on 2024/10/9.
//

#ifndef COMPILER_MULEXP_H
#define COMPILER_MULEXP_H


#include "../../../util/Value.h"

class MulExp {
public:
    static Value mulExpParser();
};


#endif //COMPILER_MULEXP_H
