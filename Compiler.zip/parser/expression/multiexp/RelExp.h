/**
 * @file RelExp.h
 */
#ifndef COMPILER_RELEXP_H
#define COMPILER_RELEXP_H


class RelExp {
public:
    static void relExpParser();
};


#endif //COMPILER_RELEXP_H
