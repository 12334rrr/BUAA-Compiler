/**
 * @file Cond.h
 * @brief Class for Cond
 * @version 1.0
 * @date 2024-10-10
 * @Author  王春博
 */

#ifndef COMPILER_COND_H
#define COMPILER_COND_H


class Cond {
public:
    static void condParser();
};


#endif //COMPILER_COND_H
