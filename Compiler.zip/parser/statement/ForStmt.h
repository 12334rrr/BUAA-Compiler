/**
 * @file ForStmt.h
 * @brief For statement class
 * @version 1.0
 * @date 2024-10-10
 * @Author  王春博
 */

#ifndef COMPILER_FORSTMT_H
#define COMPILER_FORSTMT_H


class ForStmt {
public:
    static void forStmtParser();
};


#endif //COMPILER_FORSTMT_H
