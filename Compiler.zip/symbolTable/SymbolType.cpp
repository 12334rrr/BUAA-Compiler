/**
 * @file SymbolType.cpp
 */
#include "SymbolType.h"
