/**
 * File: SymbolType.h
 *
 */
#ifndef COMPILER_SYMBOLTYPE_H
#define COMPILER_SYMBOLTYPE_H


enum class SymbolType {
    ConstChar,
    ConstInt,
    ConstCharArray,
    ConstIntArray,
    Char,
    Int,
    CharArray,
    IntArray,
    VoidFunc,
    IntFunc,
    CharFunc,
};


#endif //COMPILER_SYMBOLTYPE_H
