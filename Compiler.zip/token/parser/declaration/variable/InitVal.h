/**
 * @file InitVal.h
 * @brief Initialize value class
 * @version 1.0
 * @date 2024-10-10
 * @Author  王春博
 */

#ifndef COMPILER_INITVAL_H
#define COMPILER_INITVAL_H


class InitVal {
public:
    static void initValParser();
};


#endif //COMPILER_INITVAL_H
