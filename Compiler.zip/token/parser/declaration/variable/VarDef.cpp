/**
 * File: VarDef.cpp
 * @brief 变量定义类
 * @version 1.0
 * @date 2024-10-03
 * @Author  王春博
 */

#include "VarDef.h"
#include "../../Parser.h"
#include "../../expression/unaryexp/ConstExp.h"
#include "../../../util/Util.h"
#include "InitVal.h"
#include "../../../symbolTable/blockTree/BlockTree.h"

void VarDef::varDefParser(std::vector<SymbolItem> &itemList) {
    bool isRepeat = false;
    tokenItem token = Token::getNowToken();
    if (token.type == "IDENFR") {
        if(BlockTree::nowBlockNode->symbolTable->isSymbolPresent(token.name)){
//            Util::printSemanticErrorInfo(token.lineNum, "b");
            isRepeat = true;
        } else {
            itemList.emplace_back(token.name);
        }
        token = Token::getNextToken();
    }
    if (token.name == "[") {
        if(!isRepeat) {
            itemList.at(itemList.size() - 1).type = "Array";
        }
        token = Token::getNextToken();
        ConstExp::constExpParser();
        token = Token::getNowToken();
        if (token.name == "]") {
            token = Token::getNextToken();
        } else {
            Util::printErrorInfo(token.lineNum, "k");
        }
    }
    if(token.name == "="){
        token = Token::getNextToken();
        InitVal::initValParser();
    }
    Util::printParserInfo("<VarDef>");
}
