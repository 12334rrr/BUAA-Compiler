/**
 * ConstDef.cpp -- Parse const definition
 * @Author  王春博
 */

#include "ConstDef.h"
#include "../../token/Token.h"
#include "../expression/unaryexp/ConstExp.h"
#include "../../util/Util.h"
#include "ConstInitVal.h"
#include "../../symbolTable/blockTree/BlockTree.h"

void ConstDef::constDefParser(std::vector<SymbolItem>& itemList) {
    SymbolTable *symbolTable = BlockTree::nowBlockNode->symbolTable;
    tokenItem token = Token::getNowToken();
    if(token.type == "IDENFR"){
        if(symbolTable->isSymbolPresent(token.name)){
            Util::printSemanticErrorInfo(token.lineNum,"b");
        }
        else{
            itemList.emplace_back(token.name);
        }
        token = Token::getNextToken();
    }
    if(token.name == "["){
        itemList.at(itemList.size()-1).type = "Array";
        token = Token::getNextToken();
        ConstExp::constExpParser();
        token = Token::getNowToken();
        if(token.name == "]"){
            token = Token::getNextToken();
        }
        else{
            Util::printErrorInfo(token.lineNum,"k");
        }
    }
    token = Token::getNowToken();
    if(token.name == "="){
        token = Token::getNextToken();
    }
    ConstInitVal::constInitValParser();
    Util::printParserInfo("<ConstDef>");
}
