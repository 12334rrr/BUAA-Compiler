//
// Created by hp on 2024/10/9.
//

#ifndef COMPILER_MULEXP_H
#define COMPILER_MULEXP_H


class MulExp {
public:
    static void mulExpParser();
};


#endif //COMPILER_MULEXP_H
