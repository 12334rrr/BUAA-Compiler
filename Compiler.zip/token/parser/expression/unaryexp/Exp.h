/**
 *
 */

#ifndef COMPILER_EXP_H
#define COMPILER_EXP_H


#include <string>

class Exp {
public:
    static std::string expType;
public:
    static void expParser();
};


#endif //COMPILER_EXP_H
