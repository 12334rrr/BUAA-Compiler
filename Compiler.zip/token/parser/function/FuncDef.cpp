/**
 * @file FuncDef.cpp
 * @brief FuncDef class implementation file
 * @version 1.0
 * @date 2024-10-10
 * @Author  王春博
 */

#include <iostream>
#include "FuncDef.h"
#include "../../token/Token.h"
#include "../Parser.h"
#include "../statement/Block.h"
#include "../../util/Util.h"
#include "FuncFParams.h"
#include "../../symbolTable/blockTree/BlockTree.h"

int FuncDef::isInFunc = 0;
std::string FuncDef::funcName;
bool FuncDef::isInParam = false;
bool FuncDef::isReturn = false;

void FuncDef::funcDefParser() {
    bool isRepeat = false;
    isInParam = true;
    FuncDef::isInFunc = 1;
    std::string type;
    SymbolItem item;
    tokenItem token = Token::getNowToken();
    if (Parser::isFuncType(token)) {
        if (token.name == "void") {
            item.type = "VoidFunc";
        } else if(token.name == "int"){
            item.type = "IntFunc";
        } else if(token.name == "char"){
            item.type = "CharFunc";
        }
        token = Token::getNextToken();
    }
    Util::printParserInfo("<FuncType>");
    if (token.type == "IDENFR"){
//        SymbolTable::printAllSymbolInfo();
        if(BlockTree::nowBlockNode->symbolTable->isSymbolPresent(token.name)){
            isRepeat = true;
//            Util::printSemanticErrorInfo(token.lineNum, "b");
            token = Token::getNextToken();
        } else {
            item.name = token.name;
            FuncDef::funcName = token.name;
            token = Token::getNextToken();
        }
    }
    item.scopeIndex = BlockTree::nowBlockIndex;
    Util::printSemanticInfo(&item);

    BlockTree::createBlockNode();
    if (token.name == "(") {
        token = Token::getNextToken();
        if (Parser::isBType(token)) {
            FuncFParams::funcFParamsParser(item);
            BlockTree::nowBlockNode->parent->symbolTable->addSymbol(item);
            token = Token::getNowToken();
        }
        else{
            item.paramNum = 0;
            BlockTree::nowBlockNode->parent->symbolTable->addSymbol(item);
        }
        token = Token::getNowToken();
        if (token.name == ")") {
            token = Token::getNextToken();
        } else {
            Util::printErrorInfo(token.lineNum, "j");
        }
    }
    Block::blockParser();
    token = Token::getNowToken();
    Util::printParserInfo("<FuncDef>");
    FuncDef::isInFunc = 0;
    FuncDef::funcName = "";
    FuncDef::isReturn = false;
    isInParam = false;
    if(isRepeat){
        BlockTree::nowBlockNode->symbolTable->deleteSymbol(item);
    }
}

void FuncDef::funcDefInit() {
    FuncDef::isInFunc = false;
}
