/**
 * @file FuncRParams.cpp
 * @brief FuncRParams class
 * @version 1.0
 * @date 2024-10-03
 * @Author  王春博
 */

#include "FuncRParams.h"
#include "../../token/Token.h"
#include "../../util/Util.h"
#include "../expression/unaryexp/Exp.h"
#include <iostream>

std::string FuncRParams::funcRParamType;

void FuncRParams::funcRParamsParser(const SymbolItem &symbolItem, int lineNum) {
    Exp::expType = SymbolTable::getSymbolItem(symbolItem.name).type;
    std::vector<std::string> expTypeList;
    Exp::expParser();
    expTypeList.push_back(Exp::expType);
    tokenItem token = Token::getNowToken();
    while (token.name == ",") {
        token = Token::getNextToken();
        Exp::expParser();
        expTypeList.push_back(Exp::expType);
        token = Token::getNowToken();
    }
    if (expTypeList.size() != symbolItem.paramNum) {
//        Util::printSemanticErrorInfo(lineNum, "d");
    } else {
        for (auto i = 0; i < expTypeList.size(); i++) {
            if (!checkFuncRParams(expTypeList[i], symbolItem.paramTypeList[i])) {
                Util::printSemanticErrorInfo(lineNum, "e");
                break;
            }
        }
    }
    Util::printParserInfo("<FuncRParams>");
}

bool FuncRParams::checkFuncRParams(const std::string &callerType, const std::string &calleeType) {
    if (callerType.find("Array") != std::string::npos && calleeType.find("Array") != std::string::npos) {
        if (callerType.find("Int") != std::string::npos && calleeType.find("Int") != std::string::npos) {
            return true;
        } else if (callerType.find("Char") != std::string::npos && calleeType.find("Char") != std::string::npos) {
            return true;
        } else {
            return false;
        }
    } else if (callerType.find("Array") == std::string::npos && calleeType.find("Array") == std::string::npos) {
        return true;
    } else {
        return false;
    }
}
