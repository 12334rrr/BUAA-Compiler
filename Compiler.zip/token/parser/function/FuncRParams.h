/**
 * File: FuncRParams.h
 */

#ifndef COMPILER_FUNCRPARAMS_H
#define COMPILER_FUNCRPARAMS_H


#include "../../symbolTable/SymbolItem.h"

class FuncRParams {
public:
    static std::string funcRParamType;
public :
    static void funcRParamsParser(const SymbolItem &item,int lineNum);
    static bool checkFuncRParams(const std::string &callerType,const std::string &calleeType);
};


#endif //COMPILER_FUNCRPARAMS_H
