/**
 *
 */

#ifndef COMPILER_SYMBOLITEM_H
#define COMPILER_SYMBOLITEM_H

#include <string>
#include <vector>

class SymbolItem {
public:
    std::string name;
    std::string type;
    int scopeIndex;
    int value;
    int arraySize;
    int paramNum;
    std::vector<std::string> paramTypeList;

public:
    explicit SymbolItem();
    explicit SymbolItem(std::string name);
    explicit SymbolItem(int scopeIndex);
    explicit SymbolItem(std::string name, std::string type, int scopeIndex, int value, int arraySize, int paramNum);
    explicit SymbolItem(std::string name, std::string type, int scopeIndex, int value, int arraySize, int paramNum,
               const std::vector<std::string> &paramTypeList);
};

#endif // COMPILER_SYMBOLITEM_H